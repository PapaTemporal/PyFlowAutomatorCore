import { fail } from '@sveltejs/kit';
import { alerts, createAlert } from '$lib/server/db';
import type { Actions, PageServerLoad } from './$types';

export const load: PageServerLoad = () => {
  return {
    alerts
  };
};

export const actions = {
  create: async ({ request }) => {
    const formData = await request.formData();
    
    // Extract core fields
    const name = formData.get('name')?.toString();
    const description = formData.get('description')?.toString() || '';
    const sourceId = formData.get('sourceId')?.toString();
    const metric = formData.get('metric')?.toString();
    
    // Extract thresholds
    const threshold = formData.get('threshold')?.toString();
    const thresholdType = formData.get('thresholdType')?.toString(); // above/below
    
    // Extract time settings
    const interval = formData.get('interval')?.toString();
    const evaluationPeriod = formData.get('evaluationPeriod')?.toString();
    
    // Extract notification settings 
    const notificationType = formData.get('notificationType')?.toString(); // email/slack/etc
    const notificationTarget = formData.get('notificationTarget')?.toString();

    // Validate required fields
    if (!name || !sourceId || !metric || !threshold || !thresholdType || !interval) {
      return fail(400, {
        error: 'Missing required fields',
        // Return current values to repopulate form
        data: {
          name,
          description,
          sourceId,
          metric,
          threshold,
          thresholdType,
          interval,
          evaluationPeriod,
          notificationType,
          notificationTarget
        }
      });
    }

    // Type conversions and validation
    const sourceIdNum = parseInt(sourceId);
    const thresholdNum = parseFloat(threshold);
    const intervalNum = parseInt(interval);
    const evalPeriodNum = evaluationPeriod ? parseInt(evaluationPeriod) : 1;

    if (isNaN(sourceIdNum) || isNaN(thresholdNum) || isNaN(intervalNum) || isNaN(evalPeriodNum)) {
      return fail(400, {
        error: 'Invalid numeric values provided',
        data: { name, description, sourceId, metric, threshold, thresholdType, interval }
      });
    }

    try {
      const newAlert = createAlert({
        name,
        description,
        sourceId: sourceIdNum,
        metric,
        threshold: thresholdNum,
        thresholdType,
        interval: intervalNum,
        evaluationPeriod: evalPeriodNum,
        notificationType,
        notificationTarget
      });

      return { success: true, alert: newAlert };
      
    } catch (error) {
      console.error('Failed to create alert:', error);
      return fail(500, {
        error: 'Failed to create alert',
        data: { name, description, sourceId, metric, threshold, thresholdType, interval }
      });
    }
  }
} satisfies Actions;