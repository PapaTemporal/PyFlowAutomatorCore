<script lang="ts">
  import { enhance } from '$app/forms';
  import type { PageData } from './$types';

  let { data }: { data: PageData } = $props();
</script>

<h1>Alerts</h1>

<div class="alerts-list">
  {#each data.alerts as alert}
      <div class="alert-item">
          <h3>{alert.name}</h3>
          <p>{alert.description}</p>
          <div class="alert-details">
              <p>Severity: {alert.config.severity}</p>
              <p>Schedule: {alert.config.schedulingMode}</p>
          </div>
      </div>
  {/each}
</div>

<form method="POST" action="?/create" use:enhance>
  <!-- Basic Information -->
  <fieldset>
      <legend>Basic Information</legend>
      <div>
          <label for="name">Name</label>
          <input id="name" name="name" required>
      </div>

      <div>
          <label for="description">Description</label>
          <textarea id="description" name="description"></textarea>
      </div>

      <div>
          <label for="sourceId">Source</label>
          <select id="sourceId" name="sourceId" required>
              {#each data.sources as source}
                  <option value={source.id}>{source.name}</option>
              {/each}
          </select>
      </div>

      <div>
          <label for="severity">Severity</label>
          <select id="severity" name="severity" required>
              <option value="low">Low</option>
              <option value="medium">Medium</option>
              <option value="high">High</option>
              <option value="critical">Critical</option>
          </select>
      </div>
  </fieldset>

  <!-- Search and Scheduling -->
  <fieldset>
      <legend>Search Configuration</legend>
      <div>
          <label for="search">Search Query</label>
          <textarea id="search" name="search" required></textarea>
      </div>

      <div>
          <label for="schedulingMode">Scheduling Mode</label>
          <select id="schedulingMode" name="schedulingMode" required>
              <option value="scheduled">Scheduled</option>
              <option value="realtime">Real-time</option>
          </select>
      </div>

      <div>
          <label for="cronSchedule">Cron Schedule</label>
          <input id="cronSchedule" name="cronSchedule" placeholder="*/5 * * * *">
      </div>
  </fieldset>

  <!-- Trigger Conditions -->
  <fieldset>
      <legend>Trigger Conditions</legend>
      <div>
          <label for="triggerType">Trigger Type</label>
          <select id="triggerType" name="triggerType" required>
              <option value="number_of_events">Number of Events</option>
              <option value="field_value">Field Value</option>
          </select>
      </div>

      <div>
          <label for="threshold">Threshold</label>
          <input id="threshold" name="threshold" type="number" required>
      </div>

      <div>
          <label for="timespan">Time Span (seconds)</label>
          <input id="timespan" name="timespan" type="number" required>
      </div>

      <div>
          <label for="relation">Relation</label>
          <select id="relation" name="relation" required>
              <option value="greater than">Greater Than</option>
              <option value="less than">Less Than</option>
              <option value="equal to">Equal To</option>
          </select>
      </div>
  </fieldset>

  <!-- Notifications -->
  <fieldset>
      <legend>Notifications</legend>
      <div>
          <label for="emailRecipients">Email Recipients (comma-separated)</label>
          <input id="emailRecipients" name="emailRecipients" type="text">
      </div>

      <div>
          <label for="webhookUrl">Webhook URL</label>
          <input id="webhookUrl" name="webhookUrl" type="url">
      </div>

      <div>
          <label for="webhookMethod">Webhook Method</label>
          <select id="webhookMethod" name="webhookMethod">
              <option value="POST">POST</option>
              <option value="PUT">PUT</option>
          </select>
      </div>
  </fieldset>

  <!-- Suppression -->
  <fieldset>
      <legend>Alert Suppression</legend>
      <div>
          <label>
              <input type="checkbox" name="suppressionEnabled">
              Enable Suppression
          </label>
      </div>

      <div>
          <label for="suppressionDuration">Suppression Duration (seconds)</label>
          <input id="suppressionDuration" name="suppressionDuration" type="number">
      </div>
  </fieldset>

  <!-- Expiration -->
  <fieldset>
      <legend>Alert Expiration</legend>
      <div>
          <label>
              <input type="checkbox" name="expirationEnabled">
              Enable Expiration
          </label>
      </div>

      <div>
          <label for="ttl">Time to Live (seconds)</label>
          <input id="ttl" name="ttl" type="number">
      </div>

      <div>
          <label for="autoResolveMessage">Auto-resolve Message</label>
          <input id="autoResolveMessage" name="autoResolveMessage" type="text">
      </div>
  </fieldset>

  <!-- Throttling -->
  <fieldset>
      <legend>Alert Throttling</legend>
      <div>
          <label>
              <input type="checkbox" name="throttlingEnabled">
              Enable Throttling
          </label>
      </div>

      <div>
          <label for="maxAlertsPerHour">Max Alerts Per Hour</label>
          <input id="maxAlertsPerHour" name="maxAlertsPerHour" type="number">
      </div>

      <div>
          <label for="cooldownPeriod">Cooldown Period (seconds)</label>
          <input id="cooldownPeriod" name="cooldownPeriod" type="number">
      </div>

      <div>
          <label for="groupBy">Group By Fields (comma-separated)</label>
          <input id="groupBy" name="groupBy" type="text">
      </div>
  </fieldset>

  <button type="submit">Create Alert</button>
</form>

<style>
  fieldset {
      margin: 1rem 0;
      padding: 1rem;
      border: 1px solid #ccc;
      border-radius: 4px;
  }

  legend {
      font-weight: bold;
      padding: 0 0.5rem;
  }

  .alert-item {
      margin: 1rem 0;
      padding: 1rem;
      border: 1px solid #ddd;
      border-radius: 4px;
  }

  form div {
      margin: 0.5rem 0;
  }

  label {
      display: block;
      margin-bottom: 0.25rem;
  }

  input, select, textarea {
      width: 100%;
      padding: 0.5rem;
      border: 1px solid #ccc;
      border-radius: 4px;
  }

  button {
      margin-top: 1rem;
      padding: 0.5rem 1rem;
      background-color: #007bff;
      color: white;
      border: none;
      border-radius: 4px;
      cursor: pointer;
  }

  button:hover {
      background-color: #0056b3;
  }
</style>