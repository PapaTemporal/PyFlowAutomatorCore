<script lang="ts">
    import { enhance } from '$app/forms';
    import type { PageData } from './$types';
  
    let { data }: { data: PageData } = $props();
  </script>
  
  <h1>Sources</h1>
  
  <div class="sources-list">
    {#each data.sources as source}
      <div class="source-item">
        <h3>{source.name}</h3>
        <p>{source.description}</p>
      </div>
    {/each}
  </div>
  
  <form method="POST" action="?/create" use:enhance>
    <div>
      <label for="name">Name</label>
      <input id="name" name="name" required>
    </div>
    
    <div>
      <label for="type">Type</label>
      <select id="type" name="type" required>
        <option value="DYNATRACE">Dynatrace</option>
        <!-- other options -->
      </select>
    </div>
  
    <div>
      <label for="url">URL</label>
      <input id="url" name="url" type="url" required>
    </div>
  
    <div>
      <label for="credentials">Credentials</label>
      <select id="credentials" name="credentials">
        <option value="BASIC">Basic</option>
        <option value="OAUTH2">Oauth2</option>
      </select>
    </div>
  
    <button type="submit">Add Source</button>
  </form>