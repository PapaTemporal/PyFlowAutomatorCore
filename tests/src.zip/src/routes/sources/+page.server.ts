import { fail } from '@sveltejs/kit';
import { sources, createSource } from '$lib/server/db';
import type { Actions, PageServerLoad } from './$types';

export const load: PageServerLoad = () => {
  return {
    sources
  };
};

export const actions = {
  create: async ({ request }) => {
    const formData = await request.formData();
    const name = formData.get('name');
    const type = formData.get('type');
    const description = formData.get('description');
    const url = formData.get('url');
    const username = formData.get('username');
    const password = formData.get('password');

    if (!name || !type || !url) {
      return fail(400, { 
        error: 'Missing required fields'
      });
    }

    const newSource = createSource({
      name: name.toString(),
      type: type.toString(),
      description: description?.toString() || '',
      credentials: username && password ? 'basic' : 'none',
      config: {
        url: url.toString()
      }
    });

    return { success: true, source: newSource };
  }
} satisfies Actions;