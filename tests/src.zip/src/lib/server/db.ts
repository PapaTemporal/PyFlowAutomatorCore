import type { Alert, Source } from './$types';

// In-memory database (in a real app this would be a proper DB)
export const sources: Source[] = [
    {
        id: 1,
        name: 'source1',
        type: 'SPLUNK',
        description: 'source1 description',
        credentials: 'basic',
        config: {
            url: 'http://source1.com',
            backupUrls: ['http://source1-backup1.com', 'http://source1-backup2.com']
        }
    },
    {
        id: 2,
        name: 'source2',
        type: 'GRAFANA',
        description: 'source2 description',
        credentials: 'oauth2',
        config: {
            url: 'http://source2.com',
            backupUrls: ['http://source2-backup1.com', 'http://source2-backup2.com']
        }
    },
    {
        id: 3,
        name: 'source3',
        type: 'DYNATRACE',
        description: 'source3 description',
        credentials: 'basic',
        config: {
            url: 'http://source3.com',
            backupUrls: ['http://source3-backup1.com', 'http://source3-backup2.com']
        }
    }
];

// Example alerts array with Splunk-specific configuration
export const alerts: Alert[] = [
    {
        id: 1,
        name: 'High Error Rate Alert',
        description: 'Monitors for elevated error rates in application logs',
        sourceId: 1,
        config: {
            search: 'index=production sourcetype=application status=error | stats count as error_count by host',
            schedulingMode: 'scheduled',
            cronSchedule: '*/5 * * * *', // Every 5 minutes
            triggerCondition: {
                type: 'number_of_events',
                threshold: 100,
                timespan: 300,  // 5 minutes in seconds
                relation: 'greater than'
            },
            actions: {
                emailNotification: {
                    recipients: ['oncall@company.com']
                },
                webhookNotification: {
                    url: 'https://api.pagerduty.com/webhook',
                    method: 'POST'
                }
            },
            severity: 'high',
            // Add new configurations
            suppression: {
                enabled: true,
                conditions: [
                    {
                        field: 'host',
                        value: 'maintenance-host'  // Suppress alerts from hosts in maintenance
                    }
                ],
                suppressionDuration: 3600  // Suppress similar alerts for 1 hour
            },
            expiration: {
                enabled: true,
                ttl: 86400, // Auto-resolve after 24 hours
                autoResolveMessage: 'Alert auto-resolved after 24 hours of activity'
            },
            throttling: {
                enabled: true,
                maxAlertsPerHour: 10,
                cooldownPeriod: 300, // Minimum 5 minutes between alerts
                groupBy: ['host', 'error_type']  // Throttle alerts per host and error type
            }
        }
    },
    // ... other alerts
];

// Database operations
export function getSource(id: number) {
  return sources.find(s => s.id === id);
}

export function getAlert(id: number) {
  return alerts.find(a => a.id === id);
}

export function createSource(source: Omit<Source, 'id'>) {
  const newSource = {
    id: sources.length + 1,
    ...source
  };
  sources.push(newSource);
  return newSource;
}

export function createAlert(alert: Omit<Alert, 'id'>) {
  const newAlert = {
    id: alerts.length + 1,
    ...alert
  };
  alerts.push(newAlert);
  return newAlert;
}