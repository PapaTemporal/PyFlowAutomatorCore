// First define a type for Splunk-specific alert configuration
export type SplunkAlertConfig = {
    search: string;
    schedulingMode: 'scheduled' | 'realtime';
    cronSchedule?: string;
    triggerCondition: {
        type: 'number_of_events' | 'field_value';
        threshold: number;
        timespan: number;
        relation: 'greater than' | 'less than' | 'equal to';
    };
    actions: {
        emailNotification?: {
            recipients: string[];
        };
        webhookNotification?: {
            url: string;
            method: string;
        };
    };
    severity: 'low' | 'medium' | 'high' | 'critical';
    // Add new configuration options
    suppression: {
        enabled: boolean;
        conditions?: {
            field: string;
            value: string;
        }[];
        suppressionDuration: number; // Duration in seconds to suppress similar alerts
    };
    expiration: {
        enabled: boolean;
        ttl: number; // Time to live in seconds before alert auto-resolves
        autoResolveMessage?: string;
    };
    throttling: {
        enabled: boolean;
        maxAlertsPerHour: number;
        cooldownPeriod: number; // Minimum seconds between alerts
        groupBy?: string[]; // Fields to group alerts by for throttling
    };
};
  
  // Update the Alert interface to use this config
  export interface Alert {
    id: number;
    name: string;
    description: string;
    sourceId: number;
    config: SplunkAlertConfig;
  }

  export interface Source {
    id: number;
    name: string;
    type: string;
    description: string;
    credentials: "basic" | "oauth2";
    config: {
      url: string;
      backupUrls?: string[];
    };
  }